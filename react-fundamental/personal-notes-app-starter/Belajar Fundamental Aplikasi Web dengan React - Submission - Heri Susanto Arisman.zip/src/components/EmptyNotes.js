import React from "react";

const EmptyNotes = () => {
  return (
    <section className="notes-list-empty">
      <p className="notes-list__empty">Tidak ada catatan</p>
    </section>
  );
};

export default EmptyNotes;
